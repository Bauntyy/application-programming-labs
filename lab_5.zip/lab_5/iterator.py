from csv import DictReader


class ImageIterator:
    """
    Класс Итератора для картинок
    """
    def __init__(self, annotation_file):
        self.images = []
        with open(annotation_file, 'r') as csvfile:
            reader = DictReader(csvfile)
            for row in reader:
                self.images.append(row['Absolute path'])
        self.index = 0

    def __iter__(self):
        return self

    def __next__(self):
        if self.index < len(self.images):
            image_path = self.images[self.index]
            self.index += 1
            return image_path
        else:
            raise StopIteration

    def __previous__(self):
        if self.index > 0:
            self.index -= 1
            image_path = self.images[self.index]
            return image_path
        else:
            raise StopIteration